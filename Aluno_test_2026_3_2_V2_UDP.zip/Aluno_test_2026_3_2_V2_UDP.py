import socket, time, csv, os
from PID_controller_2026_2_24 import pid_update
import random

HOST = "192.168.1.102"   # IP do MATLAB
CMD_PORT = 7030   # comandos para MATLAB
SENSOR_PORT = 8030      # sensores vindos do MATLAB

def parse_sensor(line):
    parts = line.split(',')
    if parts[0] != 'SENSOR' or len(parts) < 9:
        return None
    try:
        return {
            'seq': int(parts[1]),
            'k': int(parts[2]),
            't': float(parts[3]),
            'ylidar': float(parts[4]),
            'yultra': float(parts[5]),
            'yamostrado': float(parts[6]),
            'flag': int(parts[7]),
            'sensor_send_ts': float(parts[8])
        }
    except:
        return None

def main():

    # --- Socket UDP para comandos (LOCK, CONFIG, CTRL) ---
    cmd_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    cmd_addr = (HOST, CMD_PORT)

    # --- Socket UDP para receber sensores ---
    udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_sock.bind(('', SENSOR_PORT))
    udp_sock.settimeout(0.05)

    my_id = "Tiago_B"
    print("A enviar LOCK para", cmd_addr)

    #======================== LOCK ========================
    print("A enviar LOCK...")
    cmd_sock.sendto(f"LOCK,{my_id}\n".encode(), cmd_addr)

    # while True:
    #     try:
    #         data, addr = cmd_sock.recvfrom(2048)
    #         line = data.decode().strip()
    #         print("RECEBIDO:", line)
    #         if line.startswith("LOCK_ACK,OK"):
    #             break
    #     except socket.timeout:
    #         print("Sem resposta ao LOCK, a reenviar...")
    #         cmd_sock.sendto(f"LOCK,{my_id}\n".encode(), cmd_addr)
    while True:
        try:
            data, addr = udp_sock.recvfrom(2048)   # <- agora recebe na porta 6000
            line = data.decode().strip()
            print("RECEBIDO:", line)
            if line.startswith("LOCK_ACK,OK"):
                break
        except socket.timeout:
            print("Sem resposta ao LOCK, a reenviar...")
            cmd_sock.sendto(f"LOCK,{my_id}\n".encode(), cmd_addr)


    #======================== CONFIG ========================
    Tmax = float(input('Tempo de simulação Tmax [s] (ex: 60): '))
    pct_aluno = float(input('Percentagem do tempo para loading (ex: 5): '))
    next_pct = 0
    mode = input('Modo (m=modelo, r=real) [m]: ').strip() 
    ctrl = input('Controlador (re,pi,fz,op,3l,al) [3l]: ').strip()
    Ts = float(input('Período de amostragem Ts [s] (ex: 0.08): ')) 

    config_msg = f"CONFIG,{my_id},{Tmax},{mode},{ctrl},{Ts}\n"
    cmd_sock.sendto(config_msg.encode(), cmd_addr)

    # listas para estatísticas
    ts_recv_list = []
    ctrl_exec_times = []

    # while True:
    #     try:
    #         data, addr = cmd_sock.recvfrom(2048)
    #         line = data.decode().strip()
    #         print("RECEBIDO:", line)
    #         if line.startswith("CONFIG_ACK,OK"):
    #             break
    #     except socket.timeout:
    #         print("Sem CONFIG_ACK, a reenviar...")
    #         cmd_sock.sendto(config_msg.encode(), cmd_addr)
    while True:
        try:
            data, addr = udp_sock.recvfrom(2048)   # <- também aqui na 6000
            line = data.decode().strip()
            print("RECEBIDO:", line)
            if line.startswith("CONFIG_ACK,OK"):
                break
        except socket.timeout:
            print("Sem CONFIG_ACK, a reenviar...")
            cmd_sock.sendto(config_msg.encode(), cmd_addr)


    print("CONFIG aceite. A iniciar...")

    #======================== LOG ========================
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    log_filename = f"log_sensores_{timestamp}.csv"
    f = open(log_filename, "w", newline="")
    writer = csv.writer(f)
    writer.writerow(["seq","k","t","r","u","ylidar","yultra","yamostrado",
        "flag","recv_ts","sensor_send_ts","delay_s2c","jitter_s2c","recv_via"])



    #======================== LOOP PRINCIPAL ========================
    t0 = time.time()
    last_seq = -1
    #last_sample = None

    pid_state = {'e_prev':0.0, 'integral':0.0}
    seq_local = 0
    last_r = 0
    last_u = 0

    yr = [0.30,0.30,0.30,0.60,0.60,0.60,0.60,0.30,0.30,0.30]
    
    lost_total = 0
    lost_real = 0
    k_received = 0
    last_delay = None


    while True:

        pkt = None
        try:
            data, addr = udp_sock.recvfrom(2048)
            line = data.decode().strip()
            pkt = parse_sensor(line)
            
            recv_ts = time.time() - t0
            recv_via = "UDP"
            
            #PERDA DE REDE
            LOSS_PROB_SENSOR = 0.00   # 10% de perdas simuladas
            
            # FORÇAR PERDA DE SENSOR
            if random.random() < LOSS_PROB_SENSOR:
                print(f"[Python] SENSOR seq={pkt['seq']} PERDIDO AAAA (simulado)")
                pkt = None
                continue
            ################################################
        
            print(f"[Python RECEBEU] SENSOR seq={pkt['seq']}  k={pkt['k']}  t={pkt['t']:.3f} via={recv_via}")

            # progresso
            pct = (pkt['t'] / Tmax) * 100
            if pct >= next_pct:
                print(f"Experiment at {next_pct}%")
                next_pct += pct_aluno  

        except socket.timeout:
            # sem novo sensor: não processar nem enviar controlador
            pkt = None
            recv_ts = time.time() - t0
            recv_via = "TIMEOUT"

        if pkt is None:
            continue
        

        # PERDA ALGORÍTMICA (SENSOR recebido mas ignorado)
        LOSS_ALGO_SKIP = 0.00   # 5% de perdas algorítmicas

        if random.random() < LOSS_ALGO_SKIP:
            print(f"[Python] SENSOR seq={pkt['seq']} ignorado (perda algorítmica simulada)")
            # conta como perda total (porque k_received não aumenta)
            # mas NÃO deve contar como perda real de rede
            # por isso temos de manter a sequência lógica:
            last_seq = pkt['seq']   # não provocar salto artificial
            # NÃO incrementa k_received
            # NÃO calcula controlador
            # NÃO envia CTRL
            continue

        
       ########################################################
      
       
        if recv_via == "UDP":
            k_received += 1



        # PERDAS TOTAIS (k ideal vs k recebido)
        lost_total = pkt['k'] - k_received

        # PERDAS REAIS (saltos de seq - rede) 
        if last_seq >= 0 and pkt['seq'] > last_seq + 1 and recv_via == "UDP":
            lost_real += (pkt['seq'] - last_seq - 1)


        last_seq = pkt['seq']
        #last_sample = pkt

        # atraso e jitter
        delay = recv_ts - pkt['sensor_send_ts']
        if last_delay is None:
            jitter = 0
        else:
            jitter = delay - last_delay
        last_delay = delay


        ts_recv_list.append(recv_ts)

        writer.writerow([
            pkt['seq'], pkt['k'], pkt['t'], last_r, last_u,
            pkt['ylidar'], pkt['yultra'], pkt['yamostrado'],
            pkt['flag'], recv_ts, pkt['sensor_send_ts'],
            delay, jitter, recv_via
        ])

        #======================== CONTROLADOR ========================
        seq_local += 1
        p = (pkt['t'] / Tmax)
        idx = min(int( p * 10), 9)
        last_r = yr[idx]
        
        if pkt is None or pkt['yamostrado'] != pkt['yamostrado']:   # verifica NaN
            print("[Python] yamostrado é NaN → ignorado")
            continue
        
        if last_u != last_u:   # NaN check
            print("[Python] u é NaN → substituído por 0")
            last_u = 0.0

        
        t_alg0 = time.time()
        last_u, pid_state = pid_update(last_r, pkt['yamostrado'], pid_state, 0.6, 0.1, 0.0, Ts)
        if last_u != last_u:   # NaN check
            print("[Python] u é NaN → substituído por 0")
            last_u = 0.0
            
        last_u = max(-1.0, min(1.0, last_u))
        t_alg1 = time.time()
        ctrl_exec_times.append(t_alg1 - t_alg0)

        ctrl_ts = time.time() - t0
        print(f"[Python para MATLAB] CTRL seq={seq_local}  r={last_r:.3f}  u={last_u:.3f}")

        ctrl_msg = f"CTRL,{my_id},{seq_local},{ctrl_ts:.6f},{last_u:.3f},{last_r:.3f}\n"

       
        LOSS_PROB_CTRL = 0.00   # 10% de perdas simuladas        
        # FORÇAR PERDA DE CTRL
        if random.random() < LOSS_PROB_CTRL:
            print(f"[Python] CTRL seq={seq_local} NÃO ENVIADO (simulado)")
        else:
            cmd_sock.sendto(ctrl_msg.encode(), cmd_addr)

        if pkt['t'] >= Tmax:
            break


    f.close()

    #======================== ESTATÍSTICAS FINAIS ========================
    k_final = pkt['k']
    final_lost_total = lost_total
    final_lost_real = lost_real
        
    print("\n=== Ts efetivo (MATLAB → Python) ===")
    if len(ts_recv_list) > 1:
        dt_list = [ts_recv_list[i] - ts_recv_list[i-1] for i in range(1, len(ts_recv_list))]
        print("Ts médio:", sum(dt_list)/len(dt_list))
        print("Ts mínimo:", min(dt_list))
        print("Ts máximo:", max(dt_list))

    print("\n=== Tempo de execução do controlador (Python) ===")
    if ctrl_exec_times:
        print("Execução média:", sum(ctrl_exec_times)/len(ctrl_exec_times))
        print("Execução máxima:", max(ctrl_exec_times))
        
        
        print("Perdas totais:", final_lost_total)
        print("Percentagem total:", 100 * final_lost_total / k_final)
        
        print("Perdas reais:", final_lost_real)
        print("Percentagem real:", 100 * final_lost_real / k_final)
        
        print(f"[Python PERDAS] seq={pkt['seq']} k={pkt['k']} k_received={k_received} lost_total={lost_total} lost_real={lost_real}")



    print("\nSimulação terminada. Log guardado:", log_filename)

if __name__ == "__main__":
    main()
