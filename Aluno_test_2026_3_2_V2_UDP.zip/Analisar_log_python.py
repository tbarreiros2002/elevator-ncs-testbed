import csv
import sys
import matplotlib.pyplot as plt

def main(csv_file):
    seq = []
    t_sim = []
    recv_ts = []
    delay_s2c = []
    jitter_s2c = []
    recv_via = []

    with open(csv_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            seq.append(int(row['seq']))
            t_sim.append(float(row['t']))
            recv_ts.append(float(row['recv_ts']))
            delay_s2c.append(float(row['delay_s2c']))
            jitter_s2c.append(float(row['jitter_s2c']))
            recv_via.append(row['recv_via'])

    # Ts efetivo MATLAB → Python (lado cliente)
    dt = [recv_ts[i] - recv_ts[i-1] for i in range(1, len(recv_ts))]
    Ts_mean = sum(dt)/len(dt)
    Ts_min  = min(dt)
    Ts_max  = max(dt)

    print('--- Python: Ts efetivo (MATLAB → Python) ---')
    print(f'Ts médio  = {Ts_mean:.6f} s')
    print(f'Ts mínimo = {Ts_min:.6f} s')
    print(f'Ts máximo = {Ts_max:.6f} s')

    # Estatísticas de delay e jitter
    print('\n--- Delay SENSOR→CLIENT ---')
    print(f'Delay médio  = {sum(delay_s2c)/len(delay_s2c):.6f} s')
    print(f'Delay mínimo = {min(delay_s2c):.6f} s')
    print(f'Delay máximo = {max(delay_s2c):.6f} s')

    print('\n--- Jitter SENSOR→CLIENT ---')
    print(f'Jitter médio  = {sum(jitter_s2c)/len(jitter_s2c):.6f} s')
    print(f'Jitter mínimo = {min(jitter_s2c):.6f} s')
    print(f'Jitter máximo = {max(jitter_s2c):.6f} s')

    # Plots
    plt.figure(figsize=(12,8))

    plt.subplot(3,1,1)
    plt.plot(seq[1:], dt, '-o')
    plt.xlabel('seq'); plt.ylabel('Ts efetivo [s]')
    plt.title('Ts efetivo (intervalo entre receções no cliente)')
    plt.grid(True)

    plt.subplot(3,1,2)
    plt.plot(seq, delay_s2c, '-')
    plt.xlabel('seq'); plt.ylabel('Delay s→c [s]')
    plt.title('Delay SENSOR→CLIENT')
    plt.grid(True)

    plt.subplot(3,1,3)
    plt.plot(seq, jitter_s2c, '-')
    plt.xlabel('seq'); plt.ylabel('Jitter s→c [s]')
    plt.title('Jitter SENSOR→CLIENT')
    plt.grid(True)

    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    if len(sys.argv) < 2:
        csv_file = input("Nome do ficheiro CSV a analisar: ").strip()
    else:
        csv_file = sys.argv[1]

    main(csv_file)

