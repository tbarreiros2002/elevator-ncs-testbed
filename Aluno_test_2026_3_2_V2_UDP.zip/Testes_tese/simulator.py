# -*- coding: utf-8 -*-
"""
Simulator for a vertical–axis elevator model.
Generates irregular, noisy position measurements and
sends them via UDP to an observer. After all data,
sends um sinal de término ("DONE") para que o observer
saiba quando encerrar.
"""

import numpy as np
import socket
import pickle
import logging
import time
from scipy.integrate import solve_ivp

# -------------------------------------------------------------------
# 1. CONFIGURAÇÃO DE LOG
# -------------------------------------------------------------------
# Cada linha gravada em 'simulator.log' terá timestamp e mensagem.
logging.basicConfig(
    filename  = 'simulator.log',    # arquivo de saída dos logs
    filemode  = 'w',                # sobrescreve arquivo existente
    level     = logging.INFO,       # registra mensagens INFO e acima
    format    = '%(asctime)s  %(message)s',
    datefmt   = '%H:%M:%S'
)

# Registra banner de início
logging.info("=== Simulator started: sending to 192.168.10.20:5005 ===")

# -------------------------------------------------------------------
# 2. CONFIGURAÇÃO DE REDE
# -------------------------------------------------------------------
# IP e porta UDP do observer (PC B)
UDP_IP   = "192.168.10.20"
UDP_PORT = 5005

# Cria socket UDP para envio de dados
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# -------------------------------------------------------------------
# 3. PARÂMETROS DO MODELO DE ELEVADOR
# -------------------------------------------------------------------
m     = 1000.0    # massa do elevador (kg)
b     = 50.0      # coeficiente de amortecimento (N·s/m)
u_cmd = 1e3       # força constante aplicada (N)

def elevator_dynamics(t, x):
    """
    Equações contínuas do sistema:
      x[0] = posição, x[1] = velocidade
      dx/dt = [velocidade; aceleração]
      aceleração = (u_cmd - b*velocidade) / m
    """
    position, velocity = x
    acceleration = (u_cmd - b * velocity) / m
    return [velocity, acceleration]

# -------------------------------------------------------------------
# 4. SIMULAÇÃO CONTÍNUA
# -------------------------------------------------------------------
t_final = 10.0              # tempo total de simulação (s)
x0      = [0.0, 0.0]        # condição inicial [posição, velocidade]

# Integra ODE para permitir amostragem em qualquer instante t
solution = solve_ivp(
    elevator_dynamics,
    [0, t_final],
    x0,
    max_step    = 0.001,     # passo máximo de integração (s)
    dense_output= True       # fornecer interpolação contínua
)

# -------------------------------------------------------------------
# 5. GERAÇÃO DE MEDIÇÕES IRREGULARES E RUIDOSAS
# -------------------------------------------------------------------
np.random.seed(42)                        # garante repetibilidade
N_meas    = 100                           # número máximo de medições
intervals = np.random.uniform(0.05, 0.2, size=N_meas)  # intervalos aleatórios
t_meas    = np.cumsum(intervals)          # acumula para obter tempos
t_meas    = t_meas[t_meas <= t_final]     # evita ultrapassar t_final
sigma_y   = 0.01                          # desvio‐padrão do ruído de medição

# -------------------------------------------------------------------
# 6. ESPERA O OBSERVER INICIAR
# -------------------------------------------------------------------
# Permite tempo para PC B subir o observer antes de enviar dados
time.sleep(2.0)

# -------------------------------------------------------------------
# 7. LOOP DE ENVIO DE MEDIÇÕES
# -------------------------------------------------------------------
last_time = 0.0
for t_k in t_meas:
    # espera o intervalo simulado em tempo real
    time.sleep(t_k - last_time)
    last_time = t_k

    # obtém posição “verdadeira” do interpolador
    position_true = solution.sol(t_k)[0]
    # adiciona ruído gaussiano
    y = position_true + np.random.normal(0, sigma_y)

    # empacota e envia (t_k, y) por UDP
    msg = pickle.dumps((t_k, float(y)))
    sock.sendto(msg, (UDP_IP, UDP_PORT))

    # debug no console para confirmar envio
    print(f"DEBUG: sent t_k={t_k:.3f}s, y={y:.3f}m")
    # grava no log
    logging.info(f"t={t_k:.3f}s  y={y:.3f}m")

# -------------------------------------------------------------------
# 8. SINALIZAÇÃO DE TÉRMINO E SAÍDA LIMPA
# -------------------------------------------------------------------
# pequena pausa para garantir processamento da última medição
time.sleep(0.1)

# envia mensagem sentinel para fechar o observer
done_msg = pickle.dumps(("DONE", 0.0))
sock.sendto(done_msg, (UDP_IP, UDP_PORT))

logging.info("=== Simulator finished: sent DONE signal ===")
print("DEBUG: sent DONE signal, exiting simulator")
