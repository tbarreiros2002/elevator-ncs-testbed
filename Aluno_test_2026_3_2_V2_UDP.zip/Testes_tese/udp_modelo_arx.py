#!/usr/bin/env python3
import socket
import time

def main():
    HOST = ""          
    PORT = 6000       
    n_iter = 50        # Número de iterações desejadas
    Ts = 0.1          

    # Parâmetros do modelo ARX
    a = 0.8
    b = 0.2
    y = 0.0         

    # Cria um socket UDP
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((HOST, PORT))
    print("UDP Modelo (Servidor): Aguardando mensagens na porta {}...".format(PORT))
    
    for i in range(1, n_iter + 1):
        t_start = time.time()

        # Recebe dados (u) do cliente 
        data, client_addr = sock.recvfrom(1024)
        try:
            u = float(data.decode().strip())
        except ValueError:
            u = 0.0

        # Atualiza o modelo ARX
        y = a * y + b * u

        # Envia a resposta (y) ao cliente, terminada com "\n"
        reply = "{}\n".format(y).encode()
        sock.sendto(reply, client_addr)

        # Mede o tempo do ciclo completo
        cycle_time = time.time() - t_start
        print("Iteração {}: u = {:.4f}, y = {:.4f}, Tempo de ciclo = {:.4f} s".format(i, u, y, cycle_time))
        
        # Garante que o ciclo completo tenha duração aproximadamente Ts segundos
        time.sleep(max(0, Ts - cycle_time))
    
    print("Finalizando o modelo ARX (servidor UDP).")
    sock.close()

if __name__ == "__main__":
    main()
