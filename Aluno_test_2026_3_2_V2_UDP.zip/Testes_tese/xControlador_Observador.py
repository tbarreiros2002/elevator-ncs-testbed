# -*- coding: utf-8 -*-
"""
raspberry_pi.py

Observador + Controlador que simula o "cérebro" no Raspberry Pi:
 - Recebe medições irregulares (t_k, y_k) via UDP.
 - Estima posição e velocidade com um filtro de Kalman contínuo-discreto (Van-Loan).
 - Calcula comando de controlo LQR (u = -K x_hat) e aplica saturação.
 - Envia comando por UDP ao modelo e grava CSV com eventos para análise.

Notas rápidas:
 - Kalman filter: algoritmo recursivo que estima o estado de um sistema linear sujeito
   a ruído de processo e ruído de observação; fornece estimativas ótimas (em MSE) sob
   hipóteses gaussianas. Aqui usamos a versão contínua-discreta para amostragens irregulares.
 - Van-Loan: técnica que usa exponenciação matricial de um bloco 2x2 para obter
   Phi(h) e Qd(h) de forma exata para qualquer intervalo h; usada para propagação
   do filtro entre medições irregulares.
 - LQR: controlador ótimo linear que minimiza um custo quadrático J = ∫(x'Qx + u'Ru)dt;
   calcula um ganho K que gera u = -K x̂.
"""

import numpy as np
from scipy.linalg import expm, solve_continuous_are
import socket
import pickle
import threading
import time
import logging
import csv

# -------------------- Configuráveis (parâmetros que podes mudar) --------------------
MEAS_PORT = 5005
CTRL_IP   = "127.0.0.1"   # IP do modelo_elevador
CTRL_PORT = 5006

m = 1000.0
b = 50.0

dt_pub = 0.1    # intervalo de publicação periódica (s) para monitorização
u_max = 2000.0  # saturação do atuador (N)

# Covariâncias iniciais do filtro
# Qc: covariância do ruído de processo no domínio contínuo (usada por Van-Loan)
Qc = np.array([[0.0, 0.0],
               [0.0, (0.1)**2]])
# R: covariância do ruído de medição (posição)
R = np.array([[(0.01)**2]])

x0 = np.array([0.0, 0.0])  # estado inicial estimado
P0 = np.eye(2) * 1.0       # covariância inicial do erro de estimação

# Parâmetros LQR iniciais (podes recalcular com identificação)
q_p = 10.0
q_v = 1.0
Q_lqr = np.diag([q_p, q_v])
R_lqr = np.array([[1.0]])

# -------------------- Logging e CSV --------------------
logging.basicConfig(
    filename='raspberry_pi.log',
    filemode='w',
    level=logging.INFO,
    format='%(asctime)s  %(message)s',
    datefmt='%H:%M:%S'
)
logging.info("=== Raspberry Pi iniciado ===")

csv_file = open('raspberry_pi.csv', 'w', newline='')
csv_writer = csv.writer(csv_file)
csv_writer.writerow(['t_recv', 'y_meas', 'p_hat', 'v_hat', 'u_sent', 'residual'])

# -------------------- Modelo contínuo (A,B,C) usado pelo filtro --------------------
A = np.array([[0.0, 1.0],
              [0.0, -b/m]])
B = np.array([[0.0],
              [1.0/m]])
C = np.array([[1.0, 0.0]])

# -------------------- Calcular ganho LQR contínuo --------------------
def compute_lqr_gain(A, B, Q, R):
    """
    Resolve a Riccati contínua (CARE) e retorna K = R^{-1} B^T P.
    - Este K é o ganho ótimo contínuo que minimiza o custo integral J.
    - Calcular offline com pesos Q,R escolhidos com base em requisitos
      de desempenho e limites do atuador. ----> AINDA POR FAZER!!!!
    """
    P = solve_continuous_are(A, B, Q, R)
    K = np.linalg.inv(R) @ B.T @ P
    return K

K = compute_lqr_gain(A, B, Q_lqr, R_lqr)  # K shape (1,2)
logging.info("K LQR calculado: %s", K)

# -------------------- Filtro de Kalman irregular (Van-Loan) --------------------
class IrregularKalman:
    """
    Implementa um Kalman contínuo-discreto para amostragem irregular:
    - propagate_to(t): avança a estimativa e a covariância do tempo atual t_cur
      para um novo tempo t usando Van-Loan (obtém Phi(h) e Qd(h)).
    - update(y): aplica a correção de medição com a equação padrão do Kalman.
    """

    def __init__(self, A, B, C, Qc, R, x0, P0):
        self.A, self.B, self.C = A, B, C
        self.Qc, self.R = Qc, R
        self.x = x0.copy()
        self.P = P0.copy()
        self.t_cur = 0.0

    def van_loan(self, h):
        """
        Método Van-Loan:
        - Monta a matriz bloco M = [[A, Qc],[0, -A^T]] * h
        - Calcula expm(M) e extrai Phi(h) = E11 e S = E12
        - Qd(h) = Phi(h) * S * Phi(h)^T é a covariância do ruído discreto para intervalo h.
        Van-Loan dá uma forma exata (numérica) de integrar o efeito do ruído de processo
        num intervalo de tempo arbitrário h.
        """
        if h <= 0:
            # se intervalo não positivo não fazemos nada
            return np.eye(self.A.shape[0]), np.zeros_like(self.P)
        n = self.A.shape[0]
        M = np.block([
            [self.A, self.Qc],
            [np.zeros_like(self.A), -self.A.T]
        ]) * h
        E = expm(M)
        Phi = E[:n, :n]
        S = E[:n, n:]
        Qd = Phi @ S @ Phi.T
        # garantia numérica de simetria
        Qd = 0.5 * (Qd + Qd.T)
        return Phi, Qd

    def propagate_to(self, t):
        """
        Propaga a estimativa do tempo interno t_cur até t:
         - calcula h = t - t_cur
         - obtém Phi(h), Qd(h) com Van-Loan
         - x = Phi * x
         - P = Phi*P*Phi^T + Qd
         - atualiza t_cur para t
        """
        h = t - self.t_cur
        if h <= 0:
            return
        Phi, Qd = self.van_loan(h)
        self.x = Phi @ self.x
        self.P = Phi @ self.P @ Phi.T + Qd
        self.t_cur = t

    def update(self, y):
        """
        Atualização de medição do Kalman:
         - calcula S = C P C^T + R
         - ganho de Kalman Kf = P C^T S^{-1}
         - residual r = y - C x_priori
         - x_aposteriori = x_priori + Kf r
         - P_aposteriori = (I - Kf C) P_priori
        Retorna residual e S para logging/diagnóstico.
        """
        S = self.C @ self.P @ self.C.T + self.R
        Kf = self.P @ self.C.T @ np.linalg.inv(S)
        r = y - (self.C @ self.x)
        self.x = self.x + Kf @ r
        self.P = (np.eye(self.P.shape[0]) - Kf @ self.C) @ self.P
        return float(r), float(S)

# Instancia do filtro com configurações iniciais
kf = IrregularKalman(A, B, C, Qc, R, x0, P0)

# -------------------- Rede e sincronização --------------------
sock_meas = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock_meas.bind(("0.0.0.0", MEAS_PORT))
sock_ctrl = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

shutdown_evt = threading.Event()

# -------------------- Thread que recebe medições e faz update + controla --------------------
def meas_receiver():
    """
    Thread principal que:
     - Recebe pacotes (t_k, y_k).
     - Propaga o filtro até t_k e faz a atualização com y_k.
     - Calcula u = -K @ x_hat, aplica saturação e envia ao modelo.
     - Regista todos os dados num CSV para análise (t_recv, y_meas, p_hat, v_hat, u_sent, residual).
    Observações:
     - A timestamp t_k é assumida ser obtida no modelo com time.monotonic() para coerência.
     - O envio do comando é imediato após a atualização; isto representa um controlador
       que reage assim que uma nova medição é incorporada.
    """
    while not shutdown_evt.is_set():
        try:
            data, _ = sock_meas.recvfrom(1024)
            msg = pickle.loads(data)
            if isinstance(msg, tuple) and msg[0] == "DONE":
                shutdown_evt.set()
                logging.info("=== Raspberry Pi recebeu DONE ===")
                break

            t_k, y_k = msg  # desempacota timestamp e medição
            # Propaga o filtro até o tempo da medição (trata amostragem irregular)
            kf.propagate_to(t_k)
            # Atualiza o filtro com a medição y_k
            res, S = kf.update(np.array([y_k]))
            logging.info("med t=%.3fs  y=%.3f  res=%.3f", t_k, y_k, res)

            # Calcula comando com LQR (u = -K x_hat)
            # LQR: controlador ótimo linear que minimiza um custo quadrático do estado e esforço
            u_raw = float(-(K @ kf.x)[0])
            # Aplica saturação com limites realistas
            u_send = float(np.clip(u_raw, -u_max, u_max))

            # Envia o comando ao modelo
            msg_u = pickle.dumps(u_send)
            sock_ctrl.sendto(msg_u, (CTRL_IP, CTRL_PORT))
            logging.info("ctrl t=%.3fs  u=%.3fN", t_k, u_send)

            # Escreve linha no CSV para análise posterior
            p_hat, v_hat = kf.x
            csv_writer.writerow([f"{t_k:.6f}", f"{y_k:.6f}", f"{p_hat:.6f}", f"{v_hat:.6f}", f"{u_send:.6f}", f"{res:.6f}"])

        except Exception as e:
            logging.exception("meas_receiver erro: %s", e)
            shutdown_evt.set()
            break

# Inicia a thread que processa medições
threading.Thread(target=meas_receiver, daemon=True).start()

# -------------------- Loop de publicação periódica (monitorização) --------------------
# Objetivo: publicar estimativas em intervalos regulares para monitorização/plot.
# Este loop só executa enquanto não recebermos DONE.
while kf.t_cur == 0.0 and not shutdown_evt.is_set():
    # espera pela primeira medição (primeiro timestamp define referência)
    time.sleep(1e-3)

start_time = time.monotonic()
last_pub = kf.t_cur

try:
    while not shutdown_evt.is_set():
        now = time.monotonic()
        # publicações periódicas a cada dt_pub: fazemos propagate_to(pub_t) antes de publicar
        if now >= last_pub + dt_pub:
            pub_t = last_pub + dt_pub
            kf.propagate_to(pub_t)  # avança a estimativa até pub_t sem novas medições
            pos_hat, vel_hat = kf.x
            logging.info("pub t=%.3fs  pp=%.3fm  vv=%.3fm/s", pub_t, pos_hat, vel_hat)
            last_pub = pub_t
        time.sleep(1e-3)
finally:
    csv_file.close()
    logging.info("=== Raspberry Pi encerrado: simulação concluída ===")
    print("DEBUG: Raspberry Pi terminou a execução.")
