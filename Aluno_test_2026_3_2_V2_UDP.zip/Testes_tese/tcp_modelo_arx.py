#!/usr/bin/env python3
import socket
import time

def read_line(conn, timeout=5):
    """
    Lê dados do socket byte a byte até encontrar um '\n' ou até expirar o timeout.
    Retorna a linha lida (em string) ou uma string vazia se não houver dados.
    """
    conn.settimeout(timeout)  # Define timeout para operações de recv
    line = b""
    start_time = time.time()
    while True:
        try:
            byte = conn.recv(1)
            if not byte:
                # Conexão fechada pelo cliente
                break
            line += byte
            if byte == b"\n":
                break
        except socket.timeout:
            print("Timeout: Nenhum byte recebido em {} segundos.".format(timeout))
            break
        # Opcional: checa se estouramos o timeout manualmente (mesmo com settimeout, extra)
        if time.time() - start_time > timeout:
            print("Timeout (manual): Nenhum byte recebido em {} segundos.".format(timeout))
            break
    return line.decode()

def main():
    # Parâmetros do modelo ARX
    a = 0.8
    b = 0.2
    y = 0.0  # Saída inicial
    Ts = 0.1      # Tempo amostral nominal (em segundos)
    n_iter = 50   # Número de iterações do loop
    
    HOST = ""     # Vincula a todas as interfaces disponíveis
    PORT = 6000

    # Cria um socket TCP
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen(1)
        print("tcpModelo (Servidor): Aguardando conexão na porta {}...".format(PORT))
        conn, addr = s.accept()
        with conn:
            print("Conexão estabelecida com o controlador: {}".format(addr))
            for k in range(1, n_iter + 1):
                t_start = time.time()
                
                # Lê a mensagem enviada pelo controlador até terminar com "\n"
                u_str = read_line(conn)
                if u_str:
                    try:
                        u = float(u_str.strip())
                    except ValueError:
                        u = 0.0
                else:
                    u = 0.0

                # Atualiza o modelo ARX: y = a*y + b*u
                y = a * y + b * u

                # Envia a saída do modelo terminada com "\n"
                y_str = "{}\n".format(y)
                conn.sendall(y_str.encode())

                sample_time = time.time() - t_start
                print("Iteração {}: u = {:.4f}, y = {:.4f}, Tempo de amostragem = {:.4f} s".format(k, u, y, sample_time))
                time.sleep(max(0, Ts - sample_time))
            print("Finalizando o tcpModelo.")

if __name__ == "__main__":
    main()


