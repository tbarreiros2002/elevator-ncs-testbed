# -*- coding: utf-8 -*-
"""
Asynchronous continuous–discrete Kalman filter observer.
Receives medições irregulares por UDP, estima posição e velocidade,
publica estimativas em intervalos regulares e encerra ao receber
o sinal "DONE" do simulador.
"""

import numpy as np
from scipy.linalg import expm
import socket
import pickle
import threading
import time
import logging

# -------------------------------------------------------------------
# 1. CONFIGURAÇÃO DE LOG
# -------------------------------------------------------------------
# Cada linha gravada em 'observer.log' terá timestamp e mensagem.
logging.basicConfig(
    filename  = 'observer.log',
    filemode  = 'w',
    level     = logging.INFO,
    format    = '%(asctime)s  %(message)s',
    datefmt   = '%H:%M:%S'
)

# banner de início para indicar que estamos prontos
logging.info("=== Observer started: listening on UDP port 5005 ===")

# -------------------------------------------------------------------
# 2. PARÂMETROS DO MODELO E FILTRO
# -------------------------------------------------------------------
m  = 1000.0
b  = 50.0

# Matriz de estado contínuo: x = [posição; velocidade]
A = np.array([[0.0, 1.0],
              [0.0, -b/m]])
# Sem entrada de controle neste exemplo
B = np.zeros((2, 1))
# Medimos apenas a posição
C = np.array([[1.0, 0.0]])

# Ruído de processo contínuo (desconhecido), acelerações
Qc = np.array([[0.0,   0.0],
               [0.0, (0.1)**2]])
# Ruído de medição
R  = np.array([[(0.01)**2]])

# Estado inicial e incerteza inicial elevada
x0 = np.array([0.0, 0.0])
P0 = np.eye(2) * 1.0

# -------------------------------------------------------------------
# 3. CLASSE DO FILTRO DE KALMAN IRREGULAR
# -------------------------------------------------------------------
class IrregularKalman:
    def __init__(self, A, B, C, Qc, R, x0, P0):
        # armazena matrizes do sistema
        self.A, self.B, self.C = A, B, C
        # covariâncias de processo e medição
        self.Qc, self.R        = Qc, R
        # estado e covariância estimados
        self.x = x0.copy()
        self.P = P0.copy()
        # tempo da última atualização
        self.t_cur = 0.0

    def van_loan(self, h):
        """
        Computa a transição discreta Phi e o ruído Qd
        para intervalo h usando Van Loan expansion.
        """
        n = self.A.shape[0]
        M = np.block([
            [self.A,            self.Qc],
            [np.zeros_like(self.A), -self.A.T]
        ]) * h
        E   = expm(M)
        Phi = E[:n, :n]            # transição de estado
        S   = E[:n, n:]            # parte intermediária
        Qd  = Phi @ S @ Phi.T      # ruído discreto
        return Phi, Qd

    def propagate_to(self, t):
        """
        PASSO DE PREDIÇÃO: avança estado x e P
        de self.t_cur até t usando Van Loan.
        """
        h = t - self.t_cur
        if h <= 0:
            return
        Phi, Qd = self.van_loan(h)
        self.x     = Phi @ self.x
        self.P     = Phi @ self.P @ Phi.T + Qd
        self.t_cur = t

    def update(self, y):
        """
        PASSO DE CORREÇÃO: incorpora medição y.
        Retorna o residual (innovação) e sua covariância S.
        """
        S = self.C @ self.P @ self.C.T + self.R
        K = self.P @ self.C.T @ np.linalg.inv(S)
        r = y - (self.C @ self.x)
        self.x = self.x + K @ r
        self.P = (np.eye(self.P.shape[0]) - K @ self.C) @ self.P
        return r, S

# instancia o filtro
kf = IrregularKalman(A, B, C, Qc, R, x0, P0)

# -------------------------------------------------------------------
# 4. CONFIGURAÇÃO DE RECEPÇÃO UDP
# -------------------------------------------------------------------
UDP_IP   = "0.0.0.0"   # ou "192.168.10.20" para fixar interface
UDP_PORT = 5005

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((UDP_IP, UDP_PORT))

# evento que sinaliza encerramento
shutdown_evt = threading.Event()

# -------------------------------------------------------------------
# 5. THREAD DE RECEPÇÃO DE MEDIÇÕES
# -------------------------------------------------------------------
def meas_receiver():
    while True:
        data, addr = sock.recvfrom(1024)
        msg = pickle.loads(data)

        # checa pelo sentinel "DONE"
        if isinstance(msg, tuple) and msg[0] == "DONE":
            logging.info("=== Observer received DONE signal ===")
            print("DEBUG: received DONE, initiating shutdown")
            shutdown_evt.set()
            break

        # prints de debug para cada pacote
        print("DEBUG: packet from", addr, "len", len(data))
        t_k, y_k = msg
        print(f"DEBUG: unpacked t_k={t_k:.3f}, y_k={y_k:.3f}")

        # aplica predição e correção do Kalman
        kf.propagate_to(t_k)
        r, S = kf.update(np.array([y_k]))
        # registra medição e residual
        logging.info(f"med t={t_k:.3f}s  y={y_k:.3f}  res={r[0]:.3f}")

# inicia thread como daemon (encerra com o main thread)
threading.Thread(target=meas_receiver, daemon=True).start()

# -------------------------------------------------------------------
# 6. LOOP PRINCIPAL DE PUBLICAÇÃO UNIFORME
# -------------------------------------------------------------------
T_u = 0.1  # intervalo de publicação (s)

# aguarda chegada da 1ª medição ou DONE
while kf.t_cur == 0.0 and not shutdown_evt.is_set():
    time.sleep(1e-3)

start_time = time.time()
last_pub   = kf.t_cur

# publica estimativas até receber DONE
while not shutdown_evt.is_set():
    elapsed = time.time() - start_time
    if elapsed >= last_pub + T_u:
        pub_t = last_pub + T_u
        kf.propagate_to(pub_t)
        pos_hat, vel_hat = kf.x
        # registra posição e velocidade estimadas
        logging.info(
            f"pub t={pub_t:.3f}s  "
            f"pp={pos_hat:.3f}m  "
            f"vv={vel_hat:.3f}m/s"
        )
        last_pub = pub_t
    time.sleep(1e-3)

# log de encerramento limpo
logging.info("=== Observer exiting: no more data ===")
print("DEBUG: observer exit complete")
