# -*- coding: utf-8 -*-
"""
modelo_elevador.py

Simula o elevador físico em loop fechado e serve como "hardware" virtual:
 - Recebe comandos de controle (u) via UDP do Raspberry Pi.
 - Integra a equação de movimento com integrador RK4 (método numérico preciso).
 - Gera medições de posição em instantes irregulares e as envia por UDP.
 - Grava logs em ficheiro e também um CSV com t_true, posição, velocidade e u aplicado.
 - No fim envia um sentinel ("DONE") para avisar o Raspberry Pi que a experiência acabou.

Explicação breve dos termos usados:
 - RK4: Runge-Kutta de 4ª ordem, um integrador numérico que aproxima a solução de uma ODE
   com maior precisão que o método de Euler por usar avaliações intermédias da derivada.
 - Saturação: limita o valor aplicado ao atuador a um intervalo físico plausível (u_max).
"""

import numpy as np
import socket
import pickle
import logging
import time
import threading
import csv

# -------------------- Configuráveis (parâmetros que podes mudar) --------------------
# Endereços e portas UDP (para testes locais usa 127.0.0.1)
MEAS_IP   = "127.0.0.1"    # IP para onde enviar as medições (raspberry)
MEAS_PORT = 5005
CTRL_PORT = 5006           # porta onde recebemos comandos do Raspberry

# Parâmetros físicos do modelo do elevador (segundo ordem: posição e velocidade)
m = 1000.0     # massa em kg
b = 50.0       # amortecimento viscous (N·s/m)

# Simulação temporal e limites
dt = 0.001     # passo de integração (s) — integrações internas são em passos fixos
u_max = 2000.0 # limite físico do atuador (N) — saturação aplicada ao comando

# Semente para RNG para tornarmos os resultados repetíveis
seed = 42
np.random.seed(seed)

# Gerar instantes de medição irregulares: exemplo realista de jitter entre 50 e 200 ms
N_meas = 200
intervals = np.random.uniform(0.05, 0.2, size=N_meas)
t_meas = np.cumsum(intervals)
t_meas = t_meas[t_meas <= 10.0]  # limita a 10 s total de experiência
sigma_y = 0.01  # desvio padrão do ruído de medição (m)

# -------------------- Logging e CSV --------------------
# logging para análise textual linha-a-linha
logging.basicConfig(
    filename='modelo_elevador.log',
    filemode='w',
    level=logging.INFO,
    format='%(asctime)s  %(message)s',
    datefmt='%H:%M:%S'
)
logging.info("=== Modelo Elevador iniciado ===")

# CSV para análise posterior e identificação (colunas claras para a tese)
csv_file = open('modelo_elevador.csv', 'w', newline='')
csv_writer = csv.writer(csv_file)
csv_writer.writerow(['t_true', 'pos', 'vel', 'u_aplicado'])

# -------------------- Rede UDP --------------------
# Socket que recebe comandos de controle (u) do Raspberry Pi
sock_ctrl = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock_ctrl.bind(("0.0.0.0", CTRL_PORT))

# Socket que envia medições para o Raspberry Pi
sock_meas = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# -------------------- Estado e sincronização entre threads --------------------
# Estado do elevador: vetor [posição; velocidade]
x = np.array([0.0, 0.0])  # estado inicial conhecido
# Comando recebido (compartilhado entre thread network e loop de simulação)
u_cmd = 0.0
u_lock = threading.Lock()  # lock para garantir leitura/escrita segura de u_cmd
running = threading.Event()
running.set()              # flag para controlar o encerramento das threads

# -------------------- Funções do modelo --------------------
def elevator_dynamics(x, u):
    """
    Calcula a derivada do estado para o modelo físico do elevador.
    x: vetor [pos, vel]
    u: força aplicada (N)
    Retorna: derivada [vel, acc]
    A equação usada é:
      pos_dot = vel
      vel_dot = (u - b*vel) / m
    onde b é amortecimento e m é massa.
    """
    pos, vel = x
    acc = (u - b * vel) / m
    return np.array([vel, acc])

def rk4_step(x, u, dt):
    """
    Um passo do integrador RK4 para avançar o estado uma quantidade dt.
    RK4 é mais preciso que Euler para o mesmo dt porque combina 4 avaliações
    intermédias da derivada e reduz erro de truncamento.
    """
    k1 = elevator_dynamics(x, u)
    k2 = elevator_dynamics(x + 0.5*dt*k1, u)
    k3 = elevator_dynamics(x + 0.5*dt*k2, u)
    k4 = elevator_dynamics(x + dt*k3, u)
    return x + dt*(k1 + 2*k2 + 2*k3 + k4)/6

# -------------------- Thread de recepção de comando --------------------
def control_receiver():
    """
    Thread que espera por pacotes UDP com o comando u do Raspberry Pi.
    - Usa pickle para desserializar o float enviado.
    - Protege a escrita de u_cmd com u_lock.
    - Aplica saturação ao guardar o comando (garante limites físicos).
    Esta thread é daemon e corre em background até running.clear() ou erro.
    """
    global u_cmd
    while running.is_set():
        try:
            data, _ = sock_ctrl.recvfrom(1024)      # bloqueia até receber
            val = pickle.loads(data)                # desserializa (float)
            with u_lock:
                # limite físico aplicado no ponto de recepção para segurança
                u_cmd = float(np.clip(float(val), -u_max, u_max))
        except Exception as e:
            # qualquer erro é logado e thread termina
            logging.exception("control_receiver erro: %s", e)
            break

# inicia a thread que recebe os comandos
threading.Thread(target=control_receiver, daemon=True).start()

# -------------------- Loop principal de simulação --------------------
# Objetivo do loop:
#  - avançar a dinâmica em passos de dt (usando RK4)
#  - quando o tempo de simulação atingir um dos t_meas, enviar uma medição y
#  - gravar dados no CSV para posterior identificação (U,Y) e análise
start_time = time.monotonic()    # referência temporal monotónica (robusta)
meas_index = 0
next_step_time = start_time     # tempo alvo para o próximo sub-passo (deadline loop)

try:
    while meas_index < len(t_meas):
        now = time.monotonic()
        # Loop com deadline: garante que tentamos manter o passo dt estável
        if now < next_step_time:
            time.sleep(next_step_time - now)
            now = time.monotonic()

        # Ler o comando de forma segura (sem condições de corrida)
        with u_lock:
            u_local = u_cmd  # cópia local do comando para usar na integração

        # Avança um passo da simulação com RK4
        x = rk4_step(x, u_local, dt)

        # Tempo de simulação desde o início
        t_cur = time.monotonic() - start_time

        # Se ultrapassámos o tempo da próxima medição, enviamo-la
        # Aqui usamos t_meas calculados no arranque (irregulares) para simular amostragem real
        if t_cur >= t_meas[meas_index]:
            # Adiciona ruído gaussiano à medição de posição para simular sensor real
            y = x[0] + np.random.normal(0, sigma_y)
            msg = pickle.dumps((t_cur, float(y)))      # pacotes: (timestamp, medição)
            sock_meas.sendto(msg, (MEAS_IP, MEAS_PORT))# envia ao Raspberry
            # Registo no ficheiro de log para leitura humana
            logging.info("t=%.3fs  y=%.3fm  u=%.3fN", t_cur, y, u_local)
            # Escreve no CSV para posterior identificação (U,Y)
            csv_writer.writerow([f"{t_cur:.6f}", f"{x[0]:.6f}", f"{x[1]:.6f}", f"{u_local:.6f}"])
            meas_index += 1

        # Avança o deadline do passo seguinte (mantém dt constante)
        next_step_time += dt

finally:
    # Envia sentinel DONE para avisar o Raspberry Pi que a experiência terminou
    time.sleep(0.05)
    done_msg = pickle.dumps(("DONE", 0.0))
    sock_meas.sendto(done_msg, (MEAS_IP, MEAS_PORT))
    running.clear()
    csv_file.close()
    logging.info("=== Modelo Elevador terminou ===")
