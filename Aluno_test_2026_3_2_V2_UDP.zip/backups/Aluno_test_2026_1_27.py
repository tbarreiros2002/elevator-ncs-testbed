# client_test.py
import socket, time
import csv, os


HOST = '127.0.0.1'   # trocar para IP do PC-mae quando for em rede
PORT = 5000
recv_buffer = b''

def recv_line(sock, timeout=0.1):
    global recv_buffer
    sock.settimeout(timeout)
    try:
        while True:
            if b'\n' in recv_buffer:
                line, recv_buffer = recv_buffer.split(b'\n', 1)
                return line.decode().strip()
            chunk = sock.recv(1024)
            if not chunk:
                # socket fechado pelo servidor
                return None
            recv_buffer += chunk
    except socket.timeout:
        return None
    except Exception:
        return None

def parse_sensor(line):
    parts = line.split(',')
    if parts[0] != 'SENSOR' or len(parts) < 7:
        return None
    try:
        return {
            'seq': int(parts[1]),
            't': float(parts[2]),
            'ylidar': float(parts[3]),
            'yultra': float(parts[4]),
            'yfusao': float(parts[5]),
            'flag': int(parts[6])
        }
    except:
        return None

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.connect((HOST, PORT))
    except Exception as e:
        print('Erro ao conectar:', e)
        return
    print('Conectado ao servidor', HOST, PORT)

    my_id = 'aluno_test'

    # 1) Pedir LOCK primeiro
    s.sendall(('LOCK,' + my_id + '\n').encode())
    print('LOCK enviado, a aguardar resposta...')
    start = time.time()
    lock_ok = False
    while time.time() - start < 5.0:
        line = recv_line(s, timeout=0.5)
        if line is None:
            # socket fechado ou sem dados
            continue
        print('RECEBIDO:', line)
        if line.startswith('LOCK_ACK,OK'):
            lock_ok = True
            break
        elif line.startswith('LOCK_ACK,BUSY'):
            print('Servidor ocupado. Tenta mais tarde.')
            s.close()
            return
        elif line.startswith('LOCK_ACK,ERR'):
            print('Erro no LOCK:', line)
            s.close()
            return
        time.sleep(0.05)
    if not lock_ok:
        print('Sem resposta ao LOCK. Abortando.')
        s.close()
        return

    # 2) Pedir inputs ao aluno (interativo)
    try:
        Tmax = float(input('Tempo de simulação Tmax [s] (ex: 60): '))
    except:
        Tmax = 60.0
    mode = input('Modo (m=modelo, r=real) [m]: ').strip() or 'm'
    controller = input('Controlador (re,pi,fz,op,3l) [3l]: ').strip() or '3l'

    # 3) Enviar CONFIG (sem reconfirmação de LOCK depois)
    config = 'CONFIG,{id},{tmax:.2f},{mode},{ctrl}\n'.format(
        id=my_id, tmax=Tmax, mode=mode, ctrl=controller)
    s.sendall(config.encode())
    print('CONFIG enviado:', config.strip())

    # 4) Esperar CONFIG_ACK
    start = time.time()
    ack_ok = False
    while time.time() - start < 5.0:
        line = recv_line(s, timeout=0.5)
        if line is None:
            continue
        print('RECEBIDO:', line)
        if line.startswith('CONFIG_ACK,OK'):
            ack_ok = True
            break
        elif line.startswith('CONFIG_ACK,ERR'):
            print('CONFIG recusado pelo servidor:', line)
            s.close()
            return
        time.sleep(0.05)
    if not ack_ok:
        print('Sem CONFIG_ACK. Abortando.')
        s.close()
        return

    print('CONFIG aceite. A iniciar ciclo de controlo...')
    
    # preparar ficheiro CSV
    log_filename = 'log_sensores.csv'
    write_header = not os.path.exists(log_filename)
    
    f = open(log_filename, 'a', newline='')
    writer = csv.writer(f)
    
    if write_header:
        writer.writerow(['seq', 't', 'ylidar', 'yultra', 'yfusao', 'flag', 'recv_ts'])

    # 5) Entrar no loop normal SENSOR <-> CTRL (sem reenviar LOCK)

    seq_local = 0
    loop_start = time.time()
   try:
    while True:
        line = recv_line(s, timeout=0.1)
        if line:
            pkt = parse_sensor(line)
            if pkt:
                # guardar no CSV
                writer.writerow([
                    pkt['seq'], pkt['t'], pkt['ylidar'],
                    pkt['yultra'], pkt['yfusao'], pkt['flag'],
                    time.time()
                ])

                # enviar CTRL a cada 5 pacotes (como antes)
                if pkt['seq'] % 5 == 0 and pkt['flag'] == 0:
                    seq_local += 1
                    u = 0.3 * (0.5 + 0.5 * (((pkt['seq'] // 5) % 2)))
                    r = 0.5
                    ctrl = f'CTRL,{my_id},{seq_local},{time.time():.4f},{u:.3f},{r:.3f}\n'
                    try:
                        s.sendall(ctrl.encode())
                    except Exception:
                        break

        # sair após Tmax segundos   
        if time.time() - loop_start > Tmax:
            break

        time.sleep(0.005)

finally:
    # fechar CSV
    try:
        f.flush()
        os.fsync(f.fileno())
        f.close()
    except:
        pass

    # release lock e fechar socket
    try:
        s.sendall(('RELEASE,' + my_id + '\n').encode())
    except:
        pass
    s.close()
    print('Simulação terminada. Dados guardados em', log_filename)


if __name__ == '__main__':
    main()
