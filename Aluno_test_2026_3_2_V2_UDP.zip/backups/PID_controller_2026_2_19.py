# pid_controller.py

def pid_update(r, y, state, Kp, Ki, Kd, Ts, umin=-1.0, umax=1.0):
    """
    r     : referência
    y     : medição (yfusao)
    state : dicionário com 'e_prev' e 'integral'
    Kp,Ki,Kd : ganhos PID
    Ts    : período de amostragem
    umin, umax : saturação
    """

    e = r - y
    u = 0

    # integral
    state['integral'] += e * Ts

    # derivada
    d = (e - state['e_prev']) / Ts

    # PID bruto
    u_unsat = Kp * e + Ki * state['integral'] + Kd * d

    # saturação
    u = max(umin, min(umax, u_unsat))
    
    #anti-windup 
    if u!= u_unsat:
        state['integral'] -= e * Ts

    # guardar estado
    state['e_prev'] = e

    return u, state

