# client_test.py
import socket, time
import csv, os
import matplotlib.pyplot as plt
from PID_controller_2026_2_24 import pid_update


HOST = '192.168.1.102'   # trocar para IP do PC-mae quando for em rede
PORT = 5000
recv_buffer = b''


def recv_line(sock, timeout=0.1):
    global recv_buffer
    sock.settimeout(timeout)
    try:
        while True:
            if b'\n' in recv_buffer:
                line, recv_buffer = recv_buffer.split(b'\n', 1)
                return line.decode().strip()
            chunk = sock.recv(1024)
            if not chunk:
                # socket fechado pelo servidor
                return None
            recv_buffer += chunk
    except socket.timeout:
        # timeout → sem dados, mas ligação ainda aberta
        return ''
    except Exception:
        return None


def parse_sensor(line):
    parts = line.split(',')
    if parts[0] != 'SENSOR' or len(parts) < 8:
        return None
    try:
        return {
            'seq': int(parts[1]),
            't': float(parts[2]),
            'ylidar': float(parts[3]),
            'yultra': float(parts[4]),
            'yamostrado': float(parts[5]),
            'flag': int(parts[6]),
            'sensor_send_ts': float(parts[7])

        }
    except:
        return None

def main():
    # --- UDP socket para receber sensores enviados pelo MATLAB ---
    UDP_PORT = 6000   # escolhe porta e documenta-a
    udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_sock.bind(('', UDP_PORT))   # aceita pacotes em todas as interfaces
    udp_sock.settimeout(0.05)       # timeout curto para não bloquear o loop principal
    last_seq_recv = -1
    last_sample = None
    lost_count = 0

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024*1024)
    try:
        s.connect((HOST, PORT))
    except Exception as e:
        print('Erro ao conectar:', e)
        return
    print('Conectado ao servidor', HOST, PORT)

    my_id = 'Tiago_B'

    # Pedir LOCK primeiro
    s.sendall(('LOCK,' + my_id + '\n').encode())
    print('LOCK enviado, a aguardar resposta...')
    start = time.time()
    lock_ok = False
    while time.time() - start < 5.0:
        line = recv_line(s, timeout=0.5)
        if line is None:
            # socket fechado ou sem dados
            continue
        print('RECEBIDO:', line)
        if line.startswith('LOCK_ACK,OK'):
            lock_ok = True
            break
        elif line.startswith('LOCK_ACK,BUSY'):
            print('Servidor ocupado. Tenta mais tarde.')
            s.close()
            return
        elif line.startswith('LOCK_ACK,ERR'):
            print('Erro no LOCK:', line)
            s.close()
            return
        time.sleep(0.05)
    if not lock_ok:
        print('Sem resposta ao LOCK. Abortando.')
        s.close()
        return

    # Pedir inputs ao aluno (interativo)
    try:
        Tmax = float(input('Tempo de simulação Tmax [s] (ex: 60): '))
        pct_aluno = float(input('Percentagem do tempo para loading (ex: 5): '))
        next_pct = 0
    except:
        Tmax = 60.0
        pct_aluno = 5
           
    try: 
         mode = input('Modo (m=modelo, r=real) [m]: ').strip() 
         controller = input('Controlador (re,pi,fz,op,3l,al) [3l]: ').strip()
         Ts = float(input('Período de amostragem Ts [s] (ex: 0.08): ')) 
    except KeyboardInterrupt:
        print('\nInterrompido pelo utilizador antes do CONFIG. A fechar ligação...')
        try: 
            s.sendall(f'RELEASE,{my_id}\n'.encode()) 
        except: 
            pass 
        s.close() 
        return
    except:
        Ts = 0.08

    # Enviar CONFIG 
    config = 'CONFIG,{id},{tmax:.2f},{mode},{ctrl},{ts:.4f}\n'.format(
    id=my_id, tmax=Tmax, mode=mode, ctrl=controller, ts=Ts)

    s.sendall(config.encode())
    print('CONFIG enviado:', config.strip())

    # Esperar CONFIG_ACK
    start = time.time()
    ack_ok = False
    while time.time() - start < 5.0:
        line = recv_line(s, timeout=0.5)
        if line is None:
            continue
        print('RECEBIDO:', line)
        if line.startswith('CONFIG_ACK,OK'):
            ack_ok = True
            break
        elif line.startswith('CONFIG_ACK,ERR'):
            print('CONFIG recusado pelo servidor:', line)
            s.close()
            return
        time.sleep(0.05)
    if not ack_ok:
        print('Sem CONFIG_ACK. Abortando.')
        s.close()
        return

    print('CONFIG aceite. A iniciar ciclo de controlo...')
    # Relógio relativo do Python (tempo zero da simulação)
    t0_py = time.time()
    #lista para guardar timestamps (comms)
    ts_recv_list = []
    #lista para guardar tempos (tempo de execucao do controlador)
    ctrl_exec_times = []


    
    # criar ficheiro CSV novo com timestamp
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    log_filename = f'log_sensores_{timestamp}.csv'

    f = open(log_filename, 'w', newline='')
    writer = csv.writer(f)

    # cabeçalho
    writer.writerow(['seq', 't', 'r', 'u', 'ylidar', 'yultra',                     
                     'yamostrado', 'flag', 'recv_ts', 
                     'sensor_send_ts','delay_s2c','jitter_s2c','recv_via'])

    print(f"Novo ficheiro de log criado: {log_filename}")

        


    # Entrar no loop normal SENSOR <-> CTRL 
    pid_state = {'e_prev': 0.0, 'integral': 0.0}
    
    Tu = 7.34
    Ku = 25
    Kp = (0.6*Ku)*0.1
    Ki = (2*Kp/Tu)*0.03
    Kd = (Kp*Tu/8)*0.05*0
   
    yr = [0.30, 0.30, 0.30, 0.50, 0.50, 0.50, 0.10, 0.10, 0.20, 0.20]


    seq_local = 0
    pkt = None
    last_r = 0
    last_u = 0
    #loop_start = time.time()
    try:
        while True:
            # line = recv_line(s, timeout=0.05)
            
            # if line is None:
            #     print("Servidor fechou a ligação.")
            #     break
            
            # if line == '':
            #     continue
            
            # pkt = parse_sensor(line)
            #recv_ts = time.time()
            # --- Receber sensor via UDP (exclusivo) ---
            pkt = None
            recv_via = 'UDP'
            try:
                data, addr = udp_sock.recvfrom(2048)   # espera por pacote UDP do MATLAB
                line = data.decode().strip()
                pkt = parse_sensor(line)
                recv_ts = time.time() - t0_py
                # detectar perdas por seq
                if pkt is not None:
                    if pkt['seq'] <= last_seq_recv:
                        # pacote duplicado ou fora de ordem -> ignorar
                        pkt = None
                    else:
                        if last_seq_recv >= 0 and pkt['seq'] > last_seq_recv + 1:
                            lost_count += (pkt['seq'] - last_seq_recv - 1)
                            print(f"SEQ={pkt['seq']}  LOST={lost_count}")
                            print(f"PERDA DETETADA: faltaram {pkt['seq'] - last_seq_recv - 1} pacotes")
                        last_seq_recv = pkt['seq']
                        last_sample = pkt
            except socket.timeout:
                # sem pacote UDP neste ciclo -> usar última amostra válida (se existir)
                pkt = last_sample
                recv_via = 'UDP_TIMEOUT'
            except Exception as e:
                print("Erro na receção UDP:", e)
                pkt = last_sample
                recv_via = 'UDP_ERR'

            recv_ts = time.time() - t0_py
            ts_recv_list.append(recv_ts)  
            
            if pkt is None:
                continue
            
            # --- Progresso da simulação ---
            pct = (pkt['t'] / Tmax) * 100
             
            if pct >= next_pct:
                print(f"Experiment at {next_pct}%")
                next_pct += pct_aluno

            delay_s2c = recv_ts - pkt['sensor_send_ts']
         
            if 'last_delay_s2c' not in locals():
                last_delay_s2c = delay_s2c
            
            jitter_s2c = delay_s2c - last_delay_s2c
            last_delay_s2c = delay_s2c

            if pkt:
                # guardar no CSV
                writer.writerow([
                    pkt['seq'], pkt['t'], last_r, last_u,
                    pkt['ylidar'], pkt['yultra'], pkt['yamostrado'],
                    pkt['flag'], recv_ts, pkt['sensor_send_ts'],
                    delay_s2c, jitter_s2c,recv_via
                ])
                
                ack = f"SENSOR_ACK,{recv_ts:.6f},{delay_s2c:.6f},{jitter_s2c:.6f}\n"
                s.sendall(ack.encode())


    # enviar CTRL em cada pacotes (pkt[seq] % 5 == 0, se for em cada 5 pacotes)
                if pkt['seq'] % 1 == 0 and pkt['flag'] == 0:
                    t_alg0 = time.time()
                    seq_local += 1
                    # last_u = 0.3 * (0.5 + 0.5 * (((pkt['seq'] // 5) % 2)))
                    # last_r = 0.5
                    p = pkt['t'] / Tmax
                    idx = min(int(p * 10),9)
                    last_r = yr[idx]
                    last_u, pid_state = pid_update(
                        last_r,
                        pkt['yamostrado'],
                        pid_state,
                        Kp, Ki, Kd,
                        Ts
                    )
                    last_u = max(-1.0, min(1.0,last_u))
                    ctrl_ts = time.time() - t0_py
                    ctrl = f'CTRL,{my_id},{seq_local},{ctrl_ts:.6f},{last_u:.3f},{last_r:.3f}\n'
                    #ctrl = f'CTRL,{my_id},{seq_local},{time.time():.4f},{last_u:.3f},{last_r:.3f}\n'
                    try:
                        s.sendall(ctrl.encode())
                        t_alg1 = time.time()
                        ctrl_exec_times.append(t_alg1 - t_alg0)
                    except Exception:
                        break
    
            # sair após Tmax segundos   
            if pkt is not None and pkt['t'] >= Tmax: 
                break
    
    finally:
         # --- Calcular Ts efetivo (MATLAB para Python) ---
         if len(ts_recv_list) > 1:
             dt_list = [ts_recv_list[i] - ts_recv_list[i-1] for i in range(1, len(ts_recv_list))]
             print("\n=== Ts efetivo (MATLAB → Python) ===")
             print("Ts médio:", sum(dt_list)/len(dt_list))
             print("Ts mínimo:", min(dt_list))
             print("Ts máximo:", max(dt_list))
         # --- Tempo de execução do controlador ---
         if ctrl_exec_times:
             print("\n=== Tempo de execução do controlador (Python) ===")
             print("Execução média:", sum(ctrl_exec_times)/len(ctrl_exec_times))
             print("Execução máxima:", max(ctrl_exec_times))
             

             print("\n=== Estatísticas de Perdas UDP ===")
             print("Pacotes perdidos:", lost_count)
             print("Percentagem de perda:", 100 * lost_count / last_seq_recv, "%")



         try:
             f.flush()
             os.fsync(f.fileno())
             f.close()
         except:
             pass
     
          # # agora reabrir para leitura
          # t = []
          # r = []
          # u = []
          # ylidar = []
          # yultra = []
          # yamostrado = []
     
          # with open(log_filename, 'r') as fr:
          #     reader = csv.DictReader(fr)
          #     for row in reader:
          #         t.append(float(row['t']))
          #         r.append(float(row['r']))
          #         u.append(float(row['u']))
          #         ylidar.append(float(row['ylidar']))
          #         yultra.append(float(row['yultra']))
          #         yamostrado.append(float(row['yamostrado']))
     
          # # plot
          # plt.figure(figsize=(12,6))
          # plt.plot(t, r, label='Referência (r)', color='green')
          # plt.plot(t, u, label='Comando (u)', color='red')
          # plt.plot(t, yultra, label='Ultrassons (yultra)', color='orange')
          # plt.plot(t, ylidar, label='LIDAR (ylidar)', color='blue')
          # plt.plot(t, yamostrado, label='Fusão (yamostrado)', color='purple')
     
          # plt.xlabel('Tempo de simulação [s]')
          # plt.ylabel('Valor')
          # plt.title('Referência, Comando e Sensores ao longo do tempo')
          # plt.grid(True)
          # plt.legend()
          # plt.tight_layout()
          # plt.show()
     
          # print("t inicial:", t[0])
          # print("t final:", t[-1])
          # print("N amostras:", len(t))
     
         # release lock e fechar socket
         try:
             s.sendall(('RELEASE,' + my_id + '\n').encode())
         except:
             pass
         print("DEBUG: socket fileno antes de close:", s.fileno())
         s.close()
         print("DEBUG: socket fileno depois de close:", s.fileno())
         print('Simulação terminada. Dados guardados em', log_filename)



if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt: 
        print('\nInterrompido pelo utilizador.')